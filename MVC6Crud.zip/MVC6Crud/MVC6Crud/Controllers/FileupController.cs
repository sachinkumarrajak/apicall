﻿using Microsoft.AspNetCore.Mvc;
using MVC6Crud.Data;
using MVC6Crud.Models;

namespace MVC6Crud.Controllers
{
    public class FileupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;
        public FileupController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UploadFile(int employeeId, [FromForm] IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("File is required.");
                }

                var fileName = Path.GetFileName(file.FileName);
                var filePath = Path.Combine(_environment.WebRootPath, "uploads", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var employeeFile = new EmployeeFile
                {
                    FileName = fileName,
                    FilePath = filePath,
                    EmployeeID = employeeId
                };

                _context.EmployeeFiles.Add(employeeFile);
                await _context.SaveChangesAsync();

                return Ok("File uploaded successfully.");
            }
            catch (Exception ex)
            {
                // Log the exception for debugging purposes

                return StatusCode(500, "An error occurred during file upload.");
            }

        }
    }
}
