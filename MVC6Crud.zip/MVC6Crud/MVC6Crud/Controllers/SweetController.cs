﻿using Microsoft.AspNetCore.Mvc;

namespace MVC6Crud.Controllers
{
    public class SweetController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
