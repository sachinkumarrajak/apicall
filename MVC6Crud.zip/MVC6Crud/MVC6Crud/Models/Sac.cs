﻿using System;
using System.Collections.Generic;

namespace MVC6Crud.Models;

public partial class Sac
{
    public int Id { get; set; }

    public string? Name { get; set; }
}
