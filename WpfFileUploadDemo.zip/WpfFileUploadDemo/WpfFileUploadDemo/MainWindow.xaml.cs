﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfFileUploadDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly FileUploadClient _fileUploadClient;

        public MainWindow()
        {
            InitializeComponent();
            _fileUploadClient = new FileUploadClient();
            LoadEmployees();
        }
        private async void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                var filePath = openFileDialog.FileName;
                var selectedEmployee = (Employee)EmployeeComboBox.SelectedItem;

                if (selectedEmployee != null)
                {
                    var result = await _fileUploadClient.UploadFileAsync(selectedEmployee.ID, filePath);
                    MessageBox.Show(result);
                }
                else
                {
                    MessageBox.Show("Please select an employee.");
                }
            }
        }

        private async void LoadEmployees()
        {
            var employees = new List<Employee>();

            string connectionString = "Data Source=DESKTOP-HPLKAC3;Initial Catalog=emp;Integrated Security=True;Trusted_Connection=true;MultipleActiveResultSets=True;TrustServerCertificate=True;"; // Replace with your connection string

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand("SELECT ID, Name FROM Employee", connection))
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        employees.Add(new Employee
                        {
                            ID = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                }
            }

            EmployeeComboBox.ItemsSource = employees;
        }

        //private async void UploadButton_Click(object sender, RoutedEventArgs e)
        //{
        //    var openFileDialog = new OpenFileDialog();
        //    if (openFileDialog.ShowDialog() == true)
        //    {
        //        var filePath = openFileDialog.FileName;

        //        var result = await _fileUploadClient.UploadFileAsync(filePath);

        //        MessageBox.Show(result);
        //    }
        //}
        //private async void UploadButton_Click(object sender, RoutedEventArgs e)
        //{
        //    var openFileDialog = new OpenFileDialog();
        //    if (openFileDialog.ShowDialog() == true)
        //    {
        //        var filePath = openFileDialog.FileName;
        //        var selectedEmployee = (Employee)EmployeeComboBox.SelectedItem;

        //        if (selectedEmployee != null)
        //        {
        //            var result = await _fileUploadClient.UploadFileAsync(selectedEmployee.ID, filePath);
        //            MessageBox.Show(result);
        //        }
        //        else
        //        {
        //            MessageBox.Show("Please select an employee.");
        //        }
        //    }
        //}
    }
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }

    public class FileUploadClient
    {
        private readonly HttpClient _httpClient;

        public FileUploadClient()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("https://localhost:7256/"); // Use your ASP.NET Core application's URL
        }

        public async Task<string> UploadFileAsync(int employeeId, string filePath)
        {
            try
            {
                using (var formContent = new MultipartFormDataContent())
                using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    formContent.Add(new StringContent(employeeId.ToString()), "employeeId");
                    formContent.Add(new StreamContent(fileStream), "file", System.IO.Path.GetFileName(filePath));

                    var response = await _httpClient.PostAsync("Fileup/UploadFile", formContent);
                    if (response.IsSuccessStatusCode)
                    {
                        return "File uploaded successfully.";
                    }
                    else
                    {
                        return "File upload failed.";
                    }
                }
            }
            catch (Exception ex)
            {
                return $"Error uploading file: {ex.Message}";
            }
        }
    }

    //public class FileUploadClient
    //{
    //    private readonly HttpClient _httpClient;

    //    public FileUploadClient()
    //    {
    //        _httpClient = new HttpClient();
    //        _httpClient.BaseAddress = new Uri("https://localhost:7256/");
    //    }

    //    public async Task<string> UploadFileAsync(int employeeId, string filePath)
    //    {
    //        using (var formContent = new MultipartFormDataContent())
    //        using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
    //        {
    //            formContent.Add(new StringContent(employeeId.ToString()), "employeeId");
    //            formContent.Add(new StreamContent(fileStream), "file", System.IO.Path.GetFileName(filePath));

    //            var response = await _httpClient.PostAsync("api/fileupload", formContent);
    //            if (response.IsSuccessStatusCode)
    //            {
    //                return "File uploaded successfully.";
    //            }
    //            else
    //            {
    //                return "File upload failed.";
    //            }
    //        }
    //    }
    //}
    //public class FileUploadClient
    //{
    //    private readonly HttpClient _httpClient;

    //    public FileUploadClient()
    //    {
    //        _httpClient = new HttpClient();
    //        _httpClient.BaseAddress = new Uri("http://youraspnetcoreapp/");
    //    }

    //    public async Task<string> UploadFileAsync(string filePath)
    //    {
    //        using (var formContent = new MultipartFormDataContent())
    //        using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
    //        {
    //            formContent.Add(new StreamContent(fileStream), "file", System.IO.Path.GetFileName(filePath));

    //            var response = await _httpClient.PostAsync("api/fileupload", formContent);
    //            if (response.IsSuccessStatusCode)
    //            {
    //                return "File uploaded successfully.";
    //            }
    //            else
    //            {
    //                return "File upload failed.";
    //            }
    //        }
    //    }
    //}
}
